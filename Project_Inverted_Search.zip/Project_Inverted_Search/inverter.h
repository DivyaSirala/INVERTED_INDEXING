#ifndef INVERTER_H
#define INVERTER_H

// Declare header files
#include <stdio.h>         
#include <stdio_ext.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

typedef struct Table
{
	int word_count;
	char *file_name;
	struct Table *tab_link;
}table;

typedef struct List
{
	int file_count;
	char *word;
	table *tab_link;
	struct List *link;
}list;

typedef struct Inverted_info
{
	FILE *fptr;
	char *file_name;
}Invert_info;


typedef enum
{
	SUCCESS,
	FAILURE,
	DATA_NOT_FOUND
}Status;

// Declare insert to list function
Status insert_to_list(list **head, char *data, Invert_info *file_info);
// Declare insert to table function
Status insert_to_table(list *link, char *fname);
// Declare create database function
Status create_database(list **head, char *data, Invert_info *file_info);
// Declare get word function
Status get_word(list **head, char *fname, Invert_info *file_info);
// Declare get indesx function
int get_index(char word[]);
// Declare open files function
Status open_files(Invert_info *file_info);
// Declare print database function
void print_database(list **head);
// Declare search data function
Status search_data(char *word, list **head);
// Declare sava database function
void save_database(char *filename, list **head);

#endif



