#include "inverter.h"   // Declare headerfile

void print_database(list **head)
{
		for (int i = 0; i < 26; i++)
		{
				list *temp1 = head[i];
				while (temp1)
				{
						table *temp2 = temp1->tab_link;
						printf("[%d]\t", i);
						printf("[%s]\t",temp1->word);
						printf("%d file/s\t", temp1->file_count);

						while(temp2)
						{
								printf("File : %s %d times\t", temp2->file_name, temp2->word_count);
								temp2 = temp2->tab_link;
						}
						temp1 = temp1->link;
						printf("\n");
				}
		}
}
