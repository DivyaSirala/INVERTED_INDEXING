#include "inverter.h"        // Declare header file

// Function definition for insert list function
Status insert_to_list(list **head, char *data, Invert_info *file_info)
{
		list *new = malloc(sizeof(list));

		if (new == NULL)
				return FAILURE;

		new->file_count = 0;
		new->word = malloc(strlen(data));
		strcpy(new->word, data);
		new->tab_link = NULL;
		new->link = NULL;

		if (*head == NULL)
		{
				*head = new;
				insert_to_table (new, file_info->file_name);
				return SUCCESS;
		}
		list *temp = *head;

		while (temp->link != NULL)
				temp = temp->link;

		temp->link = new;
		insert_to_table(new, file_info->file_name);
		return SUCCESS;
}

// Function definition for insert to table function
Status insert_to_table(list *link, char *fname)
{
		table *new = malloc( sizeof(table) );

		if (new == NULL)
				return SUCCESS;

		new->word_count = 0;
		new->file_name = malloc( strlen(fname) );
		strcpy(new->file_name, fname);
		new->tab_link = NULL;

		if (link->tab_link == NULL)
		{
				link->tab_link = new;
				link->file_count++;
				new->word_count++;
				return SUCCESS;
		}
		table *temp = link->tab_link;

		while (temp->tab_link != NULL)
				temp = temp->tab_link;

		temp->tab_link = new;
		link->file_count++;
		new->word_count++;
		return SUCCESS;
}



