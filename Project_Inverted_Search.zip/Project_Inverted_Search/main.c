/*
Name   	    :DIVYA SIRALA
Date 	    :19/07/2021
Description	: Inverted Search Project for doing
				1.Create database
				2.Display database
				3.Update database
				4.Search 
				5.Save database operations.
Input		: Input from user.
Output		: Create database, Display database, Update database, Search and Save database operations takes place.
*/

#include "inverter.h"          // Declare headerfile

int count;

int main(int argc, char *argv[])
{
		char choice;
		Invert_info file_info;     // Declare variable of type struct Invert_info
		list *head[26] = {NULL};
		do
		{
				int opt, i, status;           // Declare variables
				char file_name[25], word[25];

				printf("<--- Menu --->\n1.Create database\n2.Display database\n3.Update database\n4.Search \n5.Save database\nEnter your choice : ");
				scanf("%d", &opt);   // Read option

				switch (opt)
				{
						case 1: // Create database
								if (argc < 2)        // Condition for files are passed in command lines or not
								{
										printf("Error: File not pass through command line.\nPass the file names through the command line.\n");
										break;
								}
								for (i = 1; i < argc; i++)
										status = get_word(head, argv[i], &file_info);   // Call get word function

								if ( status == SUCCESS )
										printf("Data base created Successfully.\n");
								break;

						case 2: // Display database
								print_database(head);   // Call Print database function 
								break;

						case 3: // Update database
								printf("Enter the file name want to be updated : ");
								__fpurge(stdin);           // Clear the input buffer
								scanf("%s", file_name);    // Read file name from user

								status = get_word(head, file_name, &file_info);   // Call get word function

								if ( status == SUCCESS )
										printf("Update database is Successfully.\n");
								break;

						case 4: // Search
								printf("Enter the word to search : ");
								scanf("%s", word);       // Read word from user

								status = search_data(word, head);   // Call search data function

								if (status == DATA_NOT_FOUND)
										printf("\nData not found in database.\n");
								break;

						case 5: // Save database
								printf("Enter the file name to save database  : ");
								__fpurge(stdin);           // Clear the input buffer
								scanf("%s", file_name);      // Read file name from user
								save_database(file_name, head);         // Call save data base function
								printf("Save database is Successfully.\n");
								break;

						default : 
								printf("You entered invalid choice \n");


				}
				printf("\n");
				printf("Do you want to continue (y/n): ");
				scanf(" %c", &choice); 
		} while (choice == 'y' || choice == 'Y');   // If condition true repeat the excution

		return 0;
}




