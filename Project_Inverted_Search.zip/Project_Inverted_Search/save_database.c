#include "inverter.h"   // Declare headerfile

// Function definition for save database function
void save_database(char *filename, list **head)
{
		FILE *fptr = fopen(filename,"w");
		
		for (int i = 0; i < 26; i++)
		{
				list *temp1 = head[i];
				while (temp1)
				{

						table *temp2 = temp1->tab_link;
						fprintf(fptr, "#%d;\n", i);
						fprintf(fptr, "%s;",temp1->word);
						fprintf(fptr, "%d ;", temp1->file_count);

						while(temp2)
						{
								fprintf(fptr,"%s; %d ;", temp2->file_name, temp2->word_count);
								temp2 = temp2->tab_link;
						}
						fprintf(fptr,"#");
						fprintf(fptr,"\n");
						temp1 = temp1->link;
						fprintf(fptr,"\n");
				}
		}
		fclose(fptr);
}




