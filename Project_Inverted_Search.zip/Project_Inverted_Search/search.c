#include "inverter.h"      // Declare headerfile

Status search_data(char *word, list **head)
{
		int index = get_index(word);  

		list *temp1 = head[index];
		
		while (temp1)     // Logic to search the word in database files 
		{
				if ( !strcasecmp(temp1->word, word) )
				{
					        table *temp2 = temp1->tab_link;
					        printf("String [%s] is present in %d file(s):\n",temp1->word, temp1->file_count);
						
						while (temp2)
						{
								printf("In File : %s %d time(s)\n", temp2->file_name, temp2->word_count);
								temp2 = temp2->tab_link;
						}
						return SUCCESS;
				}
				else
						temp1 = temp1->link;
		}
		return DATA_NOT_FOUND;
}
