#include "inverter.h"     // Declare header file

// Function definition for create database function
Status create_database(list **head, char *data, Invert_info *file_info)
{
		if (*head == NULL)         // Condition for if head is NULL
		{
				insert_to_list(head, data, file_info);
				return SUCCESS;
		}
		list *temp1 = *head;
		while(temp1)
		{
				if ( !strcasecmp(temp1->word, data) )
				{
						table *temp2 = temp1->tab_link;
						while(temp2)
						{
								if (!strcmp(temp2->file_name, file_info->file_name))
								{
										temp2->word_count++;
										return SUCCESS;
								}
								else
										temp2 = temp2->tab_link;
						}
						insert_to_table(temp1, file_info->file_name);
						return SUCCESS;
				}
				else
						temp1 = temp1->link;
		}
		insert_to_list(head, data, file_info);
		return SUCCESS;
}

// Function definition for files open
Status open_files(Invert_info *file_info)
{
		file_info->fptr = fopen(file_info->file_name, "r");

		if (file_info->fptr == NULL)
		{
				perror("fopen");
				fprintf(stderr, "ERROR: Unable to open %s\n", file_info->file_name);

				return FAILURE;
		}

		return SUCCESS;
}

// Function definition for get index function
int get_index(char word[])
{
		return islower(word[0]) ? word[0] - 'a' : word[0] - 'A';
}

// Function definition for get word function
Status get_word(list **head, char *fname, Invert_info *file_info)
{
		file_info->file_name = malloc(strlen(fname));
		strcpy(file_info->file_name, fname);       // Copy filename

		if (open_files(file_info) == FAILURE)
				return FAILURE;

		int index, j;
		char word[50];
		while (fscanf(file_info->fptr, "%s", word) != EOF)
		{
				for(j = 0; word[j] != '\0'; j++)
				{
						if (!(isalpha(word[j])))
								word[j] = '\0';
				}
				index = get_index(word);

				if (word != NULL && word[0])
						create_database(&head[index], word, file_info);
		}
		free(file_info->file_name);
		return SUCCESS;
}



